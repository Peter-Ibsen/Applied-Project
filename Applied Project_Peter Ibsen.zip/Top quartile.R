install.packages("readxl")
install.packages("tidyverse")
install.packages("dplyr")
install.packages("stargazer")
install.packages("writexl")
library(writexl)
library(stargazer)
library(readxl)
library(tidyverse)
library(dplyr)
library(openxlsx)
library(knitr)

rm(list = ls())

#Set the working directory 

setwd("C:\Users\Peter\Dropbox\Imperial\Applied Project")

data_clean <- read_excel("Final data.xlsx")

# Summarize data

data_clean_industry <- data_clean %>%
  filter(!is.na(Market_cap_growth))

summary_data <- data_clean_industry %>%
  group_by(RBICS) %>%
  summarize(
    average_return = mean(Market_cap_growth),
    median_return = median(Market_cap_growth)
  ) %>%
  arrange(desc(average_return))

write_xlsx(summary_data, "summary_data.xlsx")

### Isolate top quartile industries

top_quartile_industries <- summary_data %>%
  arrange(desc(average_return)) %>%
  slice_head(n = ceiling(nrow(summary_data) * 0.25))

### Isolate data set for only top quartile industries

top_quartile_data <- data_clean_industry %>%
  semi_join(top_quartile_industries, by = "RBICS")

######### Hypothesis 4 - Targets outperform peers on revenue growth

top_quartile_data <- top_quartile_data %>%
  mutate(Q1 = quantile(Revenue_growth, 0.25, na.rm = TRUE),
         Q3 = quantile(Revenue_growth, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 20 * IQR,
         upper_bound = Q3 + 20 * IQR,
         outlier4 = Revenue_growth < lower_bound | Revenue_growth > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

top_quartile_data_RG <- top_quartile_data %>%
  filter(!outlier4) %>%
  select(-contains("outlier"))

top_quartile_data <- top_quartile_data %>%
  arrange(desc(Market_cap_growth)) 


# Shapiro-Wilk test
shapiro_test_H4 <- shapiro.test(top_quartile_data_RG$Revenue_growth)
print(shapiro_test_H4)

# Histogram
ggplot(top_quartile_data_RG, aes(x = Revenue_growth)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(top_quartile_data_RG, aes(sample = Revenue_growth)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test
H4_test = wilcox.test(top_quartile_data_RG$Revenue_growth, top_quartile_data_RG$Revenue_growth_peer, paired = TRUE)
print(H4_test)

median(top_quartile_data_RG$Revenue_growth)
median(top_quartile_data_RG$Revenue_growth_peer)
mean(top_quartile_data_RG$Revenue_growth)
mean(top_quartile_data_RG$Revenue_growth_peer)

differences_H4 <- top_quartile_data_RG$Revenue_growth - top_quartile_data_RG$Revenue_growth_peer

# Extract the rank information from the test result object
ranks_H4 <- H4_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H4 <- sum(differences_H4 > 0)
negative_ranks_H4 <- sum(differences_H4 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H4 <- sum(positive_ranks_H4 * ranks_H4)
sum_negative_ranks_H4 <- sum(negative_ranks_H4 * ranks_H4)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H4, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H4, "\n")


######### Hypothesis 5 - Targets outperform peers on EBITDA margin improvement

top_quartile_data <- top_quartile_data %>%
  mutate(Q1 = quantile(EBITDA_margin_delta, 0.25, na.rm = TRUE),
         Q3 = quantile(EBITDA_margin_delta, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 15 * IQR,
         upper_bound = Q3 + 15 * IQR,
         outlier6 = EBITDA_margin_delta < lower_bound | EBITDA_margin_delta > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

top_quartile_data_EBITDA <- top_quartile_data %>%
  filter(!outlier6) %>%
  select(-contains("outlier"))

# Shapiro-Wilk test
shapiro_test_H5 <- shapiro.test(top_quartile_data_EBITDA$EBITDA_margin_delta)
print(shapiro_test_H5)

# Histogram
ggplot(top_quartile_data_EBITDA, aes(x = EBITDA_margin_delta)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(top_quartile_data_EBITDA, aes(sample = EBITDA_margin_delta)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test



H5_test = wilcox.test(top_quartile_data_EBITDA$EBITDA_margin_delta, top_quartile_data_EBITDA$EBITDA_margin_delta_peer, paired = TRUE)
print(H5_test)

median(top_quartile_data_EBITDA$EBITDA_margin_delta)
median(top_quartile_data_EBITDA$EBITDA_margin_delta_peer)

mean(top_quartile_data_EBITDA$EBITDA_margin_delta)
mean(top_quartile_data_EBITDA$EBITDA_margin_delta_peer)

differences_H5 <- top_quartile_data_EBITDA$EBITDA_margin_delta - top_quartile_data_EBITDA$EBITDA_margin_delta_peer

# Extract the rank information from the test result object
ranks_H5 <- H5_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H5 <- sum(differences_H5 > 0)
negative_ranks_H5 <- sum(differences_H5 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H5 <- sum(positive_ranks_H5 * ranks_H5)
sum_negative_ranks_H5 <- sum(negative_ranks_H5 * ranks_H5)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H5, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H5, "\n")


######### Hypothesis 6 - Targets outperform peers on COGS margin improvement

top_quartile_data <- top_quartile_data %>%
  mutate(Q1 = quantile(COGS_margin_delta, 0.25, na.rm = TRUE),
         Q3 = quantile(COGS_margin_delta, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 15 * IQR,
         upper_bound = Q3 + 15 * IQR,
         outlier6 = COGS_margin_delta < lower_bound | COGS_margin_delta > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

top_quartile_data_COGS <- top_quartile_data %>%
  filter(!outlier6) %>%
  select(-contains("outlier"))


# Shapiro-Wilk test
shapiro_test_H6 <- shapiro.test(top_quartile_data_COGS$COGS_margin_delta)
print(shapiro_test_H6)

# Histogram
ggplot(top_quartile_data_COGS, aes(x = COGS_margin_delta)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(top_quartile_data_COGS, aes(sample = COGS_margin_delta)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test

top_quartile_data_COGS <- top_quartile_data_COGS %>%
  filter(!is.na(COGS_margin_delta_peer))


H6_test = wilcox.test(top_quartile_data_COGS$COGS_margin_delta, top_quartile_data_COGS$COGS_margin_delta_peer, paired = TRUE)
print(H6_test)

median(top_quartile_data_COGS$COGS_margin_delta)
median(top_quartile_data_COGS$COGS_margin_delta_peer)

mean(top_quartile_data_COGS$COGS_margin_delta)
mean(top_quartile_data_COGS$COGS_margin_delta_peer)

differences_H6 <- top_quartile_data_COGS$COGS_margin_delta - top_quartile_data_COGS$COGS_margin_delta_peer

# Extract the rank information from the test result object
ranks_H6 <- H6_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H6 <- sum(differences_H6 > 0)
negative_ranks_H6 <- sum(differences_H6 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H6 <- sum(positive_ranks_H6 * ranks_H6)
sum_negative_ranks_H6 <- sum(negative_ranks_H6 * ranks_H6)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H6, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H6, "\n")

######### Hypothesis 7 - Targets outperform peers on SG&A margin improvement

top_quartile_data <- top_quartile_data %>%
  mutate(Q1 = quantile(SGA_margin_delta, 0.25, na.rm = TRUE),
         Q3 = quantile(SGA_margin_delta, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 15 * IQR,
         upper_bound = Q3 + 15 * IQR,
         outlier7 = SGA_margin_delta < lower_bound | SGA_margin_delta > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

top_quartile_data_SGA <- top_quartile_data %>%
  filter(!outlier7) %>%
  select(-contains("outlier"))


# Shapiro-Wilk test
shapiro_test_H7 <- shapiro.test(top_quartile_data_SGA$SGA_margin_delta)
print(shapiro_test_H7)

# Histogram
ggplot(top_quartile_data_SGA, aes(x = SGA_margin_delta)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(top_quartile_data_SGA, aes(sample = SGA_margin_delta)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test

top_quartile_data_SGA <- top_quartile_data_SGA %>%
  filter(!is.na(SGA_margin_delta_peer))


H7_test = wilcox.test(top_quartile_data_SGA$SGA_margin_delta, top_quartile_data_SGA$SGA_margin_delta_peer, paired = TRUE)
print(H7_test)

median(top_quartile_data_SGA$SGA_margin_delta)
median(top_quartile_data_SGA$SGA_margin_delta_peer)
mean(top_quartile_data_SGA$SGA_margin_delta)
mean(top_quartile_data_SGA$SGA_margin_delta_peer)

differences_H7 <- top_quartile_data_SGA$SGA_margin_delta - top_quartile_data_SGA$SGA_margin_delta_peer

# Extract the rank information from the test result object
ranks_H7 <- H7_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H7 <- sum(differences_H7 > 0)
negative_ranks_H7 <- sum(differences_H7 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H7 <- sum(positive_ranks_H7 * ranks_H7)
sum_negative_ranks_H7 <- sum(negative_ranks_H7 * ranks_H7)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H7, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H7, "\n")

######### Hypothesis 8 - Targets outperform peers on cash generation

top_quartile_data <- top_quartile_data %>%
  mutate(Q1 = quantile(Cash_generation_margin_delta, 0.25, na.rm = TRUE),
         Q3 = quantile(Cash_generation_margin_delta, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 10 * IQR,
         upper_bound = Q3 + 10 * IQR,
         outlier8 = Cash_generation_margin_delta < lower_bound | Cash_generation_margin_delta > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

top_quartile_data_cash_generation <- top_quartile_data %>%
  filter(!outlier8) %>%
  select(-contains("outlier"))


# Shapiro-Wilk test
shapiro_test_H8 <- shapiro.test(top_quartile_data_cash_generation$Cash_generation_margin_delta)
print(shapiro_test_H8)

# Histogram
ggplot(top_quartile_data_cash_generation, aes(x = Cash_generation_margin_delta)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(top_quartile_data_cash_generation, aes(sample = Cash_generation_margin_delta)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test

top_quartile_data_cash_generation <- top_quartile_data_cash_generation %>%
  filter(!is.na(Cash_generation_margin_delta_peer))


H8_test = wilcox.test(top_quartile_data_cash_generation$Cash_generation_margin_delta, top_quartile_data_cash_generation$Cash_generation_margin_delta_peer, paired = TRUE)
print(H8_test)

top_quartile_data <- top_quartile_data %>%
  mutate(Q1 = quantile(Cash_generation_margin_delta_peer, 0.25, na.rm = TRUE),
         Q3 = quantile(Cash_generation_margin_delta_peer, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 10 * IQR,
         upper_bound = Q3 + 10 * IQR,
         outlier13 = Cash_generation_margin_delta_peer < lower_bound | Cash_generation_margin_delta_peer > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

top_quartile_data_cash_generation <- top_quartile_data %>%
  filter(!outlier13 & !outlier8) %>%
  select(-contains("outlier"))

median(top_quartile_data_cash_generation$Cash_generation_margin_delta)
median(top_quartile_data_cash_generation$Cash_generation_margin_delta_peer)
mean(top_quartile_data_cash_generation$Cash_generation_margin_delta)
mean(top_quartile_data_cash_generation$Cash_generation_margin_delta_peer)

differences_H8 <- top_quartile_data_cash_generation$Cash_generation_margin_delta - top_quartile_data_cash_generation$Cash_generation_margin_delta_peer

# Extract the rank information from the test result object
ranks_H8 <- H8_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H8 <- sum(differences_H8 > 0)
negative_ranks_H8 <- sum(differences_H8 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H8 <- sum(positive_ranks_H8 * ranks_H8)
sum_negative_ranks_H8 <- sum(negative_ranks_H8 * ranks_H8)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H8, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H8, "\n")


######### Hypothesis 9 - Targets outperform peers on ROA improvement

top_quartile_data <- top_quartile_data %>%
  mutate(Q1 = quantile(ROA_delta, 0.25, na.rm = TRUE),
         Q3 = quantile(ROA_delta, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 10 * IQR,
         upper_bound = Q3 + 10 * IQR,
         outlier9 = ROA_delta < lower_bound | ROA_delta > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

top_quartile_data_ROAg <- top_quartile_data %>%
  filter(!outlier9) %>%
  select(-contains("outlier"))


# Shapiro-Wilk test
shapiro_test_H9 <- shapiro.test(top_quartile_data_ROAg$ROA_delta)
print(shapiro_test_H9)

# Histogram
ggplot(top_quartile_data_ROAg, aes(x = ROA_delta)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(top_quartile_data_ROAg, aes(sample = ROA_delta)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test

top_quartile_data_ROAg <- top_quartile_data_ROAg %>%
  filter(!is.na(Assets_margin_delta_peer))


H9_test = wilcox.test(top_quartile_data_ROAg$ROA_delta, top_quartile_data_ROAg$Assets_margin_delta_peer, paired = TRUE)
print(H9_test)

median(top_quartile_data_ROAg$ROA_delta)
median(top_quartile_data_ROAg$Assets_margin_delta_peer)
mean(top_quartile_data_ROAg$ROA_delta)
mean(top_quartile_data_ROAg$Assets_margin_delta_peer)

differences_H9 <- top_quartile_data_ROAg$ROA_delta - top_quartile_data_ROAg$Assets_margin_delta_peer

# Extract the rank information from the test result object
ranks_H9 <- H9_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H9 <- sum(differences_H9 > 0)
negative_ranks_H9 <- sum(differences_H9 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H9 <- sum(positive_ranks_H9 * ranks_H9)
sum_negative_ranks_H9 <- sum(negative_ranks_H9 * ranks_H9)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H9, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H9, "\n")


######### Hypothesis 10 - Targets outperform on payout yields

top_quartile_data <- top_quartile_data %>%
  mutate(Q1 = quantile(Payout_yield_growth, 0.25, na.rm = TRUE),
         Q3 = quantile(Payout_yield_growth, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 10 * IQR,
         upper_bound = Q3 + 10 * IQR,
         outlier10 = Payout_yield_growth < lower_bound | Payout_yield_growth > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

top_quartile_data_payout_yield <- top_quartile_data %>%
  filter(!outlier10) %>%
  select(-contains("outlier"))


# Shapiro-Wilk test
shapiro_test_H10 <- shapiro.test(top_quartile_data_payout_yield$Payout_yield_growth)
print(shapiro_test_H10)

# Histogram
ggplot(top_quartile_data_payout_yield, aes(x = Payout_yield_growth)) +
  geom_histogram(binwidth = 0.001)

# QQ plot
ggplot(top_quartile_data_payout_yield, aes(sample = Payout_yield_growth)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test

top_quartile_data_payout_yield <- top_quartile_data_payout_yield %>%
  filter(!is.na(Payout_yield_growth_peer))


H10_test = wilcox.test(top_quartile_data_payout_yield$Payout_yield_growth, top_quartile_data_payout_yield$Payout_yield_growth_peer, paired = TRUE)
print(H10_test)

median(top_quartile_data_payout_yield$Payout_yield_growth)
median(top_quartile_data_payout_yield$Payout_yield_growth_peer)
mean(top_quartile_data_payout_yield$Payout_yield_growth)
mean(top_quartile_data_payout_yield$Payout_yield_growth_peer)

differences_H10 <- top_quartile_data_payout_yield$Payout_yield_growth - top_quartile_data_payout_yield$Payout_yield_growth_peer

# Extract the rank information from the test result object
ranks_H10 <- H10_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H10 <- sum(differences_H10 > 0)
negative_ranks_H10 <- sum(differences_H10 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H10 <- sum(positive_ranks_H10 * ranks_H10)
sum_negative_ranks_H10 <- sum(negative_ranks_H10 * ranks_H10)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H10, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H10, "\n")


######### Hypothesis 11 - Targets outperform on stock returns

top_quartile_data_MCG <- subset(top_quartile_data, !is.na(Market_cap_growth))

top_quartile_data <- top_quartile_data %>%
  mutate(Q1 = quantile(Market_cap_growth, 0.25, na.rm = TRUE),
         Q3 = quantile(Market_cap_growth, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 20 * IQR,
         upper_bound = Q3 + 20 * IQR,
         outlier11 = Market_cap_growth < lower_bound | Market_cap_growth > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

top_quartile_data_MCG <- top_quartile_data %>%
  filter(!outlier11) %>%
  select(-contains("outlier"))

# Shapiro-Wilk test
shapiro_test_H11 <- shapiro.test(top_quartile_data_MCG$Market_cap_growth)
print(shapiro_test_H11)

# Histogram
ggplot(top_quartile_data_MCG, aes(x = Market_cap_growth)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(top_quartile_data_MCG, aes(sample = Market_cap_growth)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test
top_quartile_data_MCG <- top_quartile_data %>%
  filter(!outlier11) %>%
  select(-contains("outlier")) %>%
  filter(!is.na(Market_cap_growth_peer))

H11_test = wilcox.test(top_quartile_data_MCG$Market_cap_growth, top_quartile_data_MCG$Market_cap_growth_peer, paired = TRUE)
print(H11_test)

return_differences = top_quartile_data_MCG$Market_cap_growth - top_quartile_data_MCG$Market_cap_growth_peer
H11_t_test = t.test(return_differences, alternative="greater", mu=0)
print(H11_t_test)

median(top_quartile_data_MCG$Market_cap_growth)
median(top_quartile_data_MCG$Market_cap_growth_peer)
mean(top_quartile_data_MCG$Market_cap_growth)
mean(top_quartile_data_MCG$Market_cap_growth_peer)

differences_H11 <- top_quartile_data_MCG$Market_cap_growth - top_quartile_data_MCG$Market_cap_growth_peer

# Extract the rank information from the test result object
ranks_H11 <- H11_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H11 <- sum(differences_H11 > 0)
negative_ranks_H11 <- sum(differences_H11 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H11 <- sum(positive_ranks_H11 * ranks_H11)
sum_negative_ranks_H11 <- sum(negative_ranks_H11 * ranks_H11)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H11, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H11, "\n")

### H11 - bootstrap version

library(boot)

# Define the statistic function to calculate the mean
bootstrap_mean <- function(top_quartile_data_MCG, indices) {
  resampled_data <- top_quartile_data_MCG[indices]
  mean_resampled <- mean(resampled_data)
  return(mean_resampled)
}


top_quartile_data_MCG$observed_difference_TQ <- top_quartile_data_MCG$Market_cap_growth - top_quartile_data_MCG$Market_cap_growth_peer

mean(top_quartile_data_MCG$observed_difference_TQ)

top_quartile_data_MCG$shifted_group1_TQ <- top_quartile_data_MCG$observed_difference_TQ - mean(top_quartile_data_MCG$observed_difference_TQ)

mean(top_quartile_data_MCG$shifted_group1_TQ)

# Perform the bootstrap analysis
set.seed(123)
B <- 100000
boot_results_shifted_group1 <- boot(top_quartile_data_MCG$shifted_group1_TQ, bootstrap_mean, R = B)

# Extract the bootstrapped mean differences from the 't' column of the boot_results_shifted_group1 object
bootstrapped_means <- boot_results_shifted_group1$t

# Create a dataframe for ggplot
bootstrapped_means_df <- data.frame(means = bootstrapped_means)

# Create the histogram
ggplot(bootstrapped_means_df, aes(x = means)) +
  geom_histogram(binwidth = 0.05, fill = "steelblue", color = "black") +
  labs(title = "Histogram of Bootstrapped Mean Differences",
       x = "Mean Difference",
       y = "Frequency") +
  theme_minimal()

# Calculate the observed mean difference
observed_mean_difference_TQ <- mean(top_quartile_data_MCG$Market_cap_growth) - mean(top_quartile_data_MCG$Market_cap_growth_peer)

# Step 3: Calculate the p-value
p_value_perm_TQ <- mean(bootstrapped_means >= observed_mean_difference_TQ)
print(p_value_perm_TQ)

######### Hypothesis 12 - Not due to luck 

#### Individual 

## Define a function that computes the alpha for a resampled dataset using the pre-calculated alphas

top_quartile_data <- top_quartile_data %>%
  mutate(Q1 = quantile(Alpha, 0.25, na.rm = TRUE),
         Q3 = quantile(Alpha, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 20 * IQR,
         upper_bound = Q3 + 20 * IQR,
         outlierAlpha = Alpha < lower_bound | Alpha > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

top_quartile_data_alpha <- top_quartile_data %>%
  filter(!outlierAlpha) %>%
  select(-contains("outlier"))

bootstrap_alpha <- function(alpha, indices) {
  resampled_alpha <- alpha[indices]
  return(resampled_alpha)
}

# Perform the bootstrap resampling using the boot() function:

library(boot)

alpha_vector <- top_quartile_data_alpha$Alpha # Access the 'Alpha' column from the 'data_clean_MCG' dataframe
alpha_vector <- alpha_vector[!is.na(alpha_vector)] # # Remove NA values from the alpha vector
boot_results <- boot(alpha_vector, bootstrap_alpha, R = 10000)


### Calculate the p-value

# Initialize a vector to store the p-values
p_values <- numeric(length(alpha_vector))

# Iterate over the alpha_vector and compare each observed alpha to the resampled alphas
for (i in 1:length(alpha_vector)) {
  observed_alpha <- alpha_vector[i]
  p_values[i] <- sum(boot_results$t[,i] >= observed_alpha) / boot_results$R
}

significance_level <- 0.05
num_significant <- sum(p_values < significance_level)
proportion_significant <- num_significant / length(p_values)

### 5% of investments have an alpha that is high enough that I can be reasonably sure that it is due to skill and not luck that the return is outsized

library(ggplot2)

ggplot(data.frame(p_values), aes(x = p_values)) +
  geom_histogram(breaks = seq(0, 1, by = 0.05), fill = "steelblue", color = "black") +
  labs(x = "p-value", y = "Frequency") +
  theme_minimal()

num_bins <- ceiling(1 + 3.322 * log10(length(p_values)))
observed_counts <- hist(p_values, breaks = seq(0, 1, by = 1/num_bins), plot = FALSE)$counts
expected_probabilities <- rep(1 / num_bins, num_bins)
chisq_test <- chisq.test(observed_counts, p = expected_probabilities)
print(chisq_test)

## probability not significantly different from a uniform distribution

#### Collective 

### Collective but studentized 

#Null hypothesis is that alpha is not different from 0 

#Define the test statistic
studentized_mean_alpha_TQ <- function(alpha, indices) {
  resampled_alpha <- alpha[indices]
  resampled_mean_alpha <- mean(resampled_alpha)
  resampled_se_alpha <- sd(resampled_alpha) / sqrt(length(resampled_alpha))
  studentized_stat <- (resampled_mean_alpha - mean(alpha)) / resampled_se_alpha
  return(c(studentized_stat, resampled_se_alpha))
}

library(boot)

## Shift  the data to 0 to test for extremity of result that I got 

mean(top_quartile_data_alpha$Alpha)

top_quartile_data_alpha$Alpha_shifted = top_quartile_data_alpha$Alpha - mean(top_quartile_data_alpha$Alpha)

mean(top_quartile_data_alpha$Alpha_shifted)

boot_results_mean_TQ <- boot(top_quartile_data_alpha$Alpha_shifted, studentized_mean_alpha_TQ, R = 1000)

# Calculate the studentized bootstrap confidence interval
boot_ci <- boot.ci(boot_results_mean_TQ, conf = 0.95, type = "stud")
print(boot_ci)

## CI includes mean of alpha, therefore it is likely luck

observed_mean_alpha_TQ1 <- mean(top_quartile_data_alpha$Alpha)

observed_se_alpha_TQ1 <- sd(top_quartile_data_alpha$Alpha) / sqrt(length(top_quartile_data_alpha$Alpha))

observed_studentized_alpha_TQ1 <- (observed_mean_alpha_TQ1 - mean(top_quartile_data_alpha$Alpha_shifted)) / observed_se_alpha_TQ1

p_value_coll_TQ1 <- sum(bootstrapped_means_df_TQ1$means >= observed_mean_alpha_TQ1) / boot_results_mean_TQ1$R

### low p-value indicates the same thing

# Mean
mean(top_quartile_data_alpha$Alpha)

# Median
median(top_quartile_data_alpha$Alpha)

# Standard deviation
sd(top_quartile_data_alpha$Alpha)

# Interquartile range (IQR)
IQR(top_quartile_data_alpha$Alpha)

print(p_value & mean_alpha & median_alpha & sd_alpha & iqr_alpha)

# Extract the bootstrapped mean alphas from the 't' column of the boot_results_mean object
bootstrapped_means_TQ_collective1 <- boot_results_mean_TQ1$t

# Create a dataframe for ggplot
bootstrapped_means_df_TQ1 <- data.frame(means = bootstrapped_means_TQ_collective1)

# Create the histogram
ggplot(bootstrapped_means_df_TQ1, aes(x = means)) +
  geom_histogram(binwidth = 0.05, fill = "steelblue", color = "black") +
  labs(title = "Histogram of Bootstrapped Mean Alphas",
       x = "Mean Alpha",
       y = "Frequency") +
  theme_minimal()
