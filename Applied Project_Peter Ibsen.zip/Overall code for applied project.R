install.packages("readxl")
install.packages("tidyverse")
install.packages("dplyr")
install.packages("stargazer")
install.packages("boot")
library(boot)
library(stargazer)
library(readxl)
library(tidyverse)
library(dplyr)
library(openxlsx)

rm(list = ls())

#Set the working directory 

setwd("C:\Users\Peter\Dropbox\Imperial\Applied Project")

data_clean <- read_excel("Final data.xlsx")

# Eliminate N/A

data_clean <- data %>%
  na.omit()

# Eliminate outliers

data_clean <- data_clean %>%
  mutate(Q1 = quantile(EBITDA_margin_delta, 0.25, na.rm = TRUE),
         Q3 = quantile(EBITDA_margin_delta, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 10 * IQR,
         upper_bound = Q3 + 10 * IQR,
         outlier = EBITDA_margin_delta < lower_bound | EBITDA_margin_delta > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)
data_clean1 <- data_clean %>%
  filter(!outlier) %>%
  select(-outlier)


#Summary statistics


column_names <- c("Revenue_growth", "Revenue_growth_peer", "COGS_growth", "COGS_growth_peer", "SGA_growth", "SGA_growth_peer", "EBITDA_growth", "EBITDA_growth_peer", "ROA_increase", "Market_cap_growth", "Market_cap_growth_peer") 
summary_stats_list <- lapply(column_names, function(col) {
  column_data <- data_clean[[col]]
  c(Median = median(column_data, na.rm = TRUE),
    Mean = mean(column_data, na.rm = TRUE),
    SD = sd(column_data, na.rm = TRUE),
    Min = min(column_data, na.rm = TRUE),
    Max = max(column_data, na.rm = TRUE),
    Q1 = quantile(column_data, 0.25, na.rm = TRUE),
    Q3 = quantile(column_data, 0.75, na.rm = TRUE))
})

summary_stats_df <- as.data.frame(summary_stats_list)
rownames(summary_stats_df) <- c("Median", "Mean", "SD", "Min", "Max", "Q1", "Q3")
colnames(summary_stats_df) <- column_names


######## Hypothesis 1 - target ROA < peer ROA

library(ggplot2)

#Eliminate outliers

data_clean <- data_clean %>%
  mutate(Q1 = quantile(ROA_entry, 0.25, na.rm = TRUE),
         Q3 = quantile(ROA_entry, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 15 * IQR,
         upper_bound = Q3 + 15 * IQR,
         outlier1 = ROA_entry < lower_bound | ROA_entry > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

data_clean_ROA <- data_clean %>%
  filter(!outlier1) %>%
  select(-contains("outlier"))

# Shapiro-Wilk test
shapiro_test_H1 <- shapiro.test(data_clean_ROA$ROA_entry)
print(shapiro_test_H1)

# Histogram
ggplot(data_clean_ROA, aes(x = ROA_entry)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(data_clean_ROA, aes(sample = ROA_entry)) +
  geom_qq() +
  geom_qq_line()

#Given that the p-value Shapiro-Wilk test is significantly below 0.05, I use Wilcoxon Signed Rank Test to test H1 - I also see fat tails in the QQ plot - again suggestion normality is not acheived. 
#The median ROA for peers is higher - so if the test is signficant. The ROA of peers is statistically significantly higher.
median(data_clean_ROA$ROA_entry)
median(data_clean_ROA$ROA_margin_entry_peer)

sd(data_clean_ROA$ROA_entry)
sd(data_clean_ROA$ROA_margin_entry_peer)

# Conduct the Wilcoxon signed-rank test
H1 = wilcox.test(data_clean_ROA$ROA_entry, data_clean_ROA$ROA_margin_entry_peer, paired = TRUE)
print(H1)

differences_H1 <- data_clean_ROA$ROA_entry - data_clean_ROA$ROA_margin_entry_peer

# Extract the rank information from the test result object
ranks_H1 <- H1$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H1 <- sum(differences_H1 > 0)
negative_ranks_H1 <- sum(differences_H1 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H1 <- sum(positive_ranks_H1 * ranks_H1)
sum_negative_ranks_H1 <- sum(negative_ranks_H1 * ranks_H1)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H1, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H1, "\n")


### The P-value is equal to 0.0102

######### Hypothesis 2 - payout yield for targets > payout yield for peers

#Elimiante outliers and N/A's

data_clean <- data_clean %>%
  mutate(Q1 = quantile(Payout_yield_at_entry, 0.25, na.rm = TRUE),
         Q3 = quantile(Payout_yield_at_entry, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 15 * IQR,
         upper_bound = Q3 + 15 * IQR,
         outlier2 = Payout_yield_at_entry < lower_bound | Payout_yield_at_entry > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

data_clean_payout <- data_clean %>%
  filter(!outlier2) %>%
  select(-contains("outlier"))

# Shapiro-Wilk test
shapiro_test_H2 <- shapiro.test(data_clean_payout$Payout_yield_at_entry)
print(shapiro_test_H2)

# Histogram
ggplot(data_clean_payout, aes(x = Payout_yield_at_entry)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(data_clean_payout, aes(sample = Payout_yield_at_entry)) +
  geom_qq() +
  geom_qq_line()

#Given that the p-value Shapiro-Wilk test is significantly below 0.05, I use Wilcoxon Signed Rank Test to test H1 - I also see fat tails in the QQ plot - again suggestion normality is not acheived. 
#The median ROA for peers is higher - so if the test is signficant. The ROA of peers is statistically significantly higher.
median(data_clean_payout$Payout_yield_at_entry)
median(data_clean_payout$Payout_yield_entry_peer)

# Conduct the Wilcoxon signed-rank test
H2 = wilcox.test(data_clean_payout$Payout_yield_at_entry, data_clean_payout$Payout_yield_entry_peer, paired = TRUE)
print(H2)

differences_H2 <- data_clean_payout$Payout_yield_at_entry - data_clean_payout$Payout_yield_entry_peer

# Extract the rank information from the test result object
ranks_H2 <- H2$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H2 <- sum(differences_H2 > 0)
negative_ranks_H2 <- sum(differences_H2 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H2 <- sum(positive_ranks_H2 * ranks_H2)
sum_negative_ranks_H2 <- sum(negative_ranks_H2 * ranks_H2)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H2, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H2, "\n")


######### Hypothesis 3 - targets have higher intitutional ownership than peers

#Elimiante outliers and N/A's

data_clean <- data_clean %>%
  mutate(Q1 = quantile(Inst_own_at_entry, 0.25, na.rm = TRUE),
         Q3 = quantile(Inst_own_at_entry, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 2 * IQR,
         upper_bound = Q3 + 2 * IQR,
         outlier3 = Inst_own_at_entry < lower_bound | Inst_own_at_entry > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

data_clean_inst_own <- data_clean %>%
  filter(!outlier3 & Inst_own_at_entry <= 1) %>%
  select(-contains("outlier"))

# Shapiro-Wilk test
shapiro_test_H3 <- shapiro.test(data_clean_inst_own$Inst_own_at_entry)
print(shapiro_test_H3)

# Histogram
ggplot(data_clean_inst_own, aes(x = Inst_own_at_entry)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(data_clean_inst_own, aes(sample = Inst_own_at_entry)) +
  geom_qq() +
  geom_qq_line()

#Given that the p-value Shapiro-Wilk test is significantly below 0.05, I use Wilcoxon Signed Rank Test to test H1 - I also see fat tails in the QQ plot - again suggestion normality is not acheived. 
#The median ROA for peers is higher - so if the test is signficant. The ROA of peers is statistically significantly higher.
median(data_clean_inst_own$Inst_own_at_entry)
median(data_clean_inst_own$Inst_own_entry_peer)

# Conduct the Wilcoxon signed-rank test
H3 = wilcox.test(data_clean_inst_own$Inst_own_at_entry, data_clean_inst_own$Inst_own_entry_peer, paired = TRUE)
print(H3)

differences_H3 <- data_clean_inst_own$Inst_own_at_entry - data_clean_inst_own$Payout_yield_entry_peer

# Extract the rank information from the test result object
ranks_H3 <- H3$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H3 <- sum(differences_H3 > 0)
negative_ranks_H3 <- sum(differences_H3 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H3 <- sum(positive_ranks_H3 * ranks_H3)
sum_negative_ranks_H3 <- sum(negative_ranks_H3 * ranks_H3)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H3, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H3, "\n")

######### Hypothesis 4 - Targets outperform peers on revenue growth

#Eliminate outliers

data_clean <- data_clean %>%
  mutate(Q1 = quantile(Revenue_growth, 0.25, na.rm = TRUE),
         Q3 = quantile(Revenue_growth, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 15 * IQR,
         upper_bound = Q3 + 15 * IQR,
         outlier4 = Revenue_growth < lower_bound | Revenue_growth > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

data_clean_Rg <- data_clean %>%
  filter(!outlier4) %>%
  select(-contains("outlier"))

# Shapiro-Wilk test
shapiro_test_H4 <- shapiro.test(data_clean_Rg$Revenue_growth)
print(shapiro_test_H4)

# Histogram
ggplot(data_clean_Rg, aes(x = Revenue_growth)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(data_clean_Rg, aes(sample = Revenue_growth)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test
H4_test = wilcox.test(data_clean_Rg$Revenue_growth, data_clean_Rg$Revenue_growth_peer, paired = TRUE)
print(H4_test)

median(data_clean_Rg$Revenue_growth)
median(data_clean_Rg$Revenue_growth_peer)
mean(data_clean_Rg$Revenue_growth)
mean(data_clean_Rg$Revenue_growth_peer)

differences_H4 <- data_clean_Rg$Revenue_growth - data_clean_Rg$Revenue_growth_peer

# Extract the rank information from the test result object
ranks_H4 <- H4_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H4 <- sum(differences_H4 > 0)
negative_ranks_H4 <- sum(differences_H4 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H4 <- sum(positive_ranks_H4 * ranks_H4)
sum_negative_ranks_H4 <- sum(negative_ranks_H4 * ranks_H4)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H4, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H4, "\n")

### The P-value is equal to 0.0000...1 meaning that it is significant at the 0.01 level. Thus, it can be concluded that revenue growth for targets is statistically lower than revenue growth for peers in the ownership period


######### Hypothesis 5 - Targets outperform peers on EBITDA margin improvement

data_clean <- data_clean %>%
  mutate(Q1 = quantile(EBITDA_margin_delta, 0.25, na.rm = TRUE),
         Q3 = quantile(EBITDA_margin_delta, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 15 * IQR,
         upper_bound = Q3 + 15 * IQR,
         outlier5 = EBITDA_margin_delta < lower_bound | EBITDA_margin_delta > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

data_clean_EBITDA <- data_clean %>%
  filter(!outlier5) %>%
  select(-contains("outlier"))


# Shapiro-Wilk test
shapiro_test_H5 <- shapiro.test(data_clean_EBITDA$EBITDA_margin_delta)
print(shapiro_test_H5)

# Histogram
ggplot(data_clean_EBITDA, aes(x = EBITDA_margin_delta)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(data_clean_EBITDA, aes(sample = EBITDA_margin_delta)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test

data_clean_EBITDA <- data_clean_EBITDA %>%
  filter(!is.na(EBITDA_margin_delta_peer))


H5_test = wilcox.test(data_clean_EBITDA$EBITDA_margin_delta, data_clean_EBITDA$EBITDA_margin_delta_peer, paired = TRUE)
print(H5_test)

median(data_clean_EBITDA$EBITDA_margin_delta)
median(data_clean_EBITDA$EBITDA_margin_delta_peer)

mean(data_clean_EBITDA$EBITDA_margin_delta)
mean(data_clean_EBITDA$EBITDA_margin_delta_peer)

differences_H5 <- data_clean_EBITDA$EBITDA_margin_delta - data_clean_EBITDA$EBITDA_margin_delta_peer

# Extract the rank information from the test result object
ranks_H5 <- H5_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H5 <- sum(differences_H5 > 0)
negative_ranks_H5 <- sum(differences_H5 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H5 <- sum(positive_ranks_H5 * ranks_H5)
sum_negative_ranks_H5 <- sum(negative_ranks_H5 * ranks_H5)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H5, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H5, "\n")


######### Hypothesis 6 - Targets outperform peers on COGS margin improvement

data_clean <- data_clean %>%
  mutate(Q1 = quantile(COGS_margin_delta, 0.25, na.rm = TRUE),
         Q3 = quantile(COGS_margin_delta, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 15 * IQR,
         upper_bound = Q3 + 15 * IQR,
         outlier6 = COGS_margin_delta < lower_bound | COGS_margin_delta > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

data_clean_COGS <- data_clean %>%
  filter(!outlier6) %>%
  select(-contains("outlier"))


# Shapiro-Wilk test
shapiro_test_H6 <- shapiro.test(data_clean_COGS$COGS_margin_delta)
print(shapiro_test_H6)

# Histogram
ggplot(data_clean_COGS, aes(x = COGS_margin_delta)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(data_clean_COGS, aes(sample = COGS_margin_delta)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test

data_clean_COGS <- data_clean_COGS %>%
  filter(!is.na(COGS_margin_delta_peer))


H6_test = wilcox.test(data_clean_COGS$COGS_margin_delta, data_clean_COGS$COGS_margin_delta_peer, paired = TRUE)
print(H6_test)

median(data_clean_COGS$COGS_margin_delta)
median(data_clean_COGS$COGS_margin_delta_peer)

mean(data_clean_COGS$COGS_margin_delta)
mean(data_clean_COGS$COGS_margin_delta_peer)

differences_H6 <- data_clean_COGS$COGS_margin_delta - data_clean_COGS$COGS_margin_delta_peer

# Extract the rank information from the test result object
ranks_H6 <- H6_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H6 <- sum(differences_H6 > 0)
negative_ranks_H6 <- sum(differences_H6 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H6 <- sum(positive_ranks_H6 * ranks_H6)
sum_negative_ranks_H6 <- sum(negative_ranks_H6 * ranks_H6)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H6, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H6, "\n")

######### Hypothesis 7 - Targets outperform peers on SG&A margin improvement

data_clean <- data_clean %>%
  mutate(Q1 = quantile(SGA_margin_delta, 0.25, na.rm = TRUE),
         Q3 = quantile(SGA_margin_delta, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 15 * IQR,
         upper_bound = Q3 + 15 * IQR,
         outlier7 = SGA_margin_delta < lower_bound | SGA_margin_delta > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

data_clean_SGA <- data_clean %>%
  filter(!outlier7) %>%
  select(-contains("outlier"))


# Shapiro-Wilk test
shapiro_test_H7 <- shapiro.test(data_clean_SGA$SGA_margin_delta)
print(shapiro_test_H7)

# Histogram
ggplot(data_clean_SGA, aes(x = SGA_margin_delta)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(data_clean_SGA, aes(sample = SGA_margin_delta)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test

data_clean_SGA <- data_clean_SGA %>%
  filter(!is.na(SGA_margin_delta_peer))


H7_test = wilcox.test(data_clean_SGA$SGA_margin_delta, data_clean_SGA$SGA_margin_delta_peer, paired = TRUE)
print(H7_test)

median(data_clean_SGA$SGA_margin_delta)
median(data_clean_SGA$SGA_margin_delta_peer)
mean(data_clean_SGA$SGA_margin_delta)
mean(data_clean_SGA$SGA_margin_delta_peer)

differences_H7 <- data_clean_SGA$SGA_margin_delta - data_clean_SGA$SGA_margin_delta_peer

# Extract the rank information from the test result object
ranks_H7 <- H7_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H7 <- sum(differences_H7 > 0)
negative_ranks_H7 <- sum(differences_H7 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H7 <- sum(positive_ranks_H7 * ranks_H7)
sum_negative_ranks_H7 <- sum(negative_ranks_H7 * ranks_H7)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H7, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H7, "\n")

######### Hypothesis 8 - Targets outperform peers on cash generation

data_clean <- data_clean %>%
  mutate(Q1 = quantile(Cash_generation_margin_delta, 0.25, na.rm = TRUE),
         Q3 = quantile(Cash_generation_margin_delta, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 10 * IQR,
         upper_bound = Q3 + 10 * IQR,
         outlier8 = Cash_generation_margin_delta < lower_bound | Cash_generation_margin_delta > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

data_clean_cash_generation <- data_clean %>%
  filter(!outlier8) %>%
  select(-contains("outlier"))


# Shapiro-Wilk test
shapiro_test_H8 <- shapiro.test(data_clean_cash_generation$Cash_generation_margin_delta)
print(shapiro_test_H8)

# Histogram
ggplot(data_clean_cash_generation, aes(x = Cash_generation_margin_delta)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(data_clean_cash_generation, aes(sample = Cash_generation_margin_delta)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test


data_clean <- data_clean %>%
  mutate(Q1 = quantile(Cash_generation_margin_delta_peer, 0.25, na.rm = TRUE),
         Q3 = quantile(Cash_generation_margin_delta_peer, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 10 * IQR,
         upper_bound = Q3 + 10 * IQR,
         outlier13 = Cash_generation_margin_delta_peer < lower_bound | Cash_generation_margin_delta_peer > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

data_clean_cash_generation <- data_clean %>%
  filter(!outlier13 & !outlier8) %>%
  select(-contains("outlier"))


H8_test = wilcox.test(data_clean_cash_generation$Cash_generation_margin_delta, data_clean_cash_generation$Cash_generation_margin_delta_peer, paired = TRUE)
print(H8_test)

median(data_clean_cash_generation$Cash_generation_margin_delta)
median(data_clean_cash_generation$Cash_generation_margin_delta_peer)
mean(data_clean_cash_generation$Cash_generation_margin_delta)
mean(data_clean_cash_generation$Cash_generation_margin_delta_peer)

differences_H8 <- data_clean_cash_generation$Cash_generation_margin_delta - data_clean_cash_generation$Cash_generation_margin_delta_peer

# Extract the rank information from the test result object
ranks_H8 <- H8_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H8 <- sum(differences_H8 > 0)
negative_ranks_H8 <- sum(differences_H8 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H8 <- sum(positive_ranks_H8 * ranks_H8)
sum_negative_ranks_H8 <- sum(negative_ranks_H8 * ranks_H8)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H8, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H8, "\n")


######### Hypothesis 9 - Targets outperform peers on ROA improvement

data_clean <- data_clean %>%
  mutate(Q1 = quantile(ROA_delta, 0.25, na.rm = TRUE),
         Q3 = quantile(ROA_delta, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 10 * IQR,
         upper_bound = Q3 + 10 * IQR,
         outlier9 = ROA_delta < lower_bound | ROA_delta > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

data_clean_ROAg <- data_clean %>%
  filter(!outlier9) %>%
  select(-contains("outlier"))


# Shapiro-Wilk test
shapiro_test_H9 <- shapiro.test(data_clean_ROAg$ROA_delta)
print(shapiro_test_H9)

# Histogram
ggplot(data_clean_ROAg, aes(x = ROA_delta)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(data_clean_ROAg, aes(sample = ROA_delta)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test

data_clean_ROAg <- data_clean_ROAg %>%
  filter(!is.na(Assets_margin_delta_peer))


H9_test = wilcox.test(data_clean_ROAg$ROA_delta, data_clean_ROAg$Assets_margin_delta_peer, paired = TRUE)
print(H9_test)

median(data_clean_ROAg$ROA_delta)
median(data_clean_ROAg$Assets_margin_delta_peer)
mean(data_clean_ROAg$ROA_delta)
mean(data_clean_ROAg$Assets_margin_delta_peer)

differences_H9 <- data_clean_ROAg$ROA_delta - data_clean_ROAg$Assets_margin_delta_peer

# Extract the rank information from the test result object
ranks_H9 <- H9_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H9 <- sum(differences_H9 > 0)
negative_ranks_H9 <- sum(differences_H9 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H9 <- sum(positive_ranks_H9 * ranks_H9)
sum_negative_ranks_H9 <- sum(negative_ranks_H9 * ranks_H9)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H9, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H9, "\n")


######### Hypothesis 10 - Targets outperform on payout yields

data_clean <- data_clean %>%
  mutate(Q1 = quantile(Payout_yield_growth, 0.25, na.rm = TRUE),
         Q3 = quantile(Payout_yield_growth, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 10 * IQR,
         upper_bound = Q3 + 10 * IQR,
         outlier10 = Payout_yield_growth < lower_bound | Payout_yield_growth > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

data_clean_payout_yield <- data_clean %>%
  filter(!outlier10) %>%
  select(-contains("outlier"))


# Shapiro-Wilk test
shapiro_test_H10 <- shapiro.test(data_clean_payout_yield$Payout_yield_growth)
print(shapiro_test_H10)

# Histogram
ggplot(data_clean_payout_yield, aes(x = Payout_yield_growth)) +
  geom_histogram(binwidth = 0.001)

# QQ plot
ggplot(data_clean_payout_yield, aes(sample = Payout_yield_growth)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test

data_clean_payout_yield <- data_clean_payout_yield %>%
  filter(!is.na(payout_yield_growth_peer))


H10_test = wilcox.test(data_clean_payout_yield$Payout_yield_growth, data_clean_payout_yield$Payout_yield_growth_peer, paired = TRUE)
print(H10_test)

median(data_clean_payout_yield$Payout_yield_growth)
median(data_clean_payout_yield$Payout_yield_growth_peer)
mean(data_clean_payout_yield$Payout_yield_growth)
mean(data_clean_payout_yield$Payout_yield_growth_peer)

differences_H10 <- data_clean_payout_yield$Payout_yield_growth - data_clean_payout_yield$Payout_yield_growth_peer

# Extract the rank information from the test result object
ranks_H10 <- H10_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H10 <- sum(differences_H10 > 0)
negative_ranks_H10 <- sum(differences_H10 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H10 <- sum(positive_ranks_H10 * ranks_H10)
sum_negative_ranks_H10 <- sum(negative_ranks_H10 * ranks_H10)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H10, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H10, "\n")


######### Hypothesis 11 - Targets outperform on stock returns
data_clean_MCG <- subset(data_clean, !is.na(Market_cap_growth))

data_clean <- data_clean %>%
  mutate(Q1 = quantile(Market_cap_growth, 0.25, na.rm = TRUE),
         Q3 = quantile(Market_cap_growth, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 20 * IQR,
         upper_bound = Q3 + 20 * IQR,
         outlier11 = Market_cap_growth < lower_bound | Market_cap_growth > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

data_clean_MCG <- data_clean %>%
  filter(!outlier11) %>%
  select(-contains("outlier"))

# Shapiro-Wilk test
shapiro_test_H11 <- shapiro.test(data_clean_MCG$Market_cap_growth)
print(shapiro_test_H11)

# Histogram
ggplot(data_clean_MCG, aes(x = Market_cap_growth)) +
  geom_histogram(binwidth = 0.01)

# QQ plot
ggplot(data_clean_MCG, aes(sample = Market_cap_growth)) +
  geom_qq() +
  geom_qq_line()

# Conduct the Wilcoxon signed-rank test

H11_test = wilcox.test(data_clean_MCG$Market_cap_growth, data_clean_MCG$Market_cap_growth_peer, paired = TRUE)
print(H11_test)

median(data_clean_MCG$Market_cap_growth)
median(data_clean_MCG$Market_cap_growth_peer)
mean(data_clean_MCG$Market_cap_growth)
mean(data_clean_MCG$Market_cap_growth_peer)

differences_H11 <- data_clean_MCG$Market_cap_growth - data_clean_MCG$Market_cap_growth_peer

# Extract the rank information from the test result object
ranks_H11 <- H11_test$statistic

# Assign the ranks to positive and negative differences
positive_ranks_H11 <- sum(differences_H11 > 0)
negative_ranks_H11 <- sum(differences_H11 < 0)

# Calculate the sum of positive and negative ranks
sum_positive_ranks_H11 <- sum(positive_ranks_H11 * ranks_H11)
sum_negative_ranks_H11 <- sum(negative_ranks_H11 * ranks_H11)

# Print the results
cat("Sum of positive ranks:", sum_positive_ranks_H11, "\n")
cat("Sum of negative ranks:", sum_negative_ranks_H11, "\n")

######### H11 - bootstrap version

library(boot)

# Define the statistic function to calculate the mean
bootstrap_mean <- function(data_clean_MCG, indices) {
  resampled_data <- data_clean_MCG[indices]
  mean_resampled <- mean(resampled_data)
  return(mean_resampled)
}


data_clean_MCG$observed_difference_TQ <- data_clean_MCG$Market_cap_growth - data_clean_MCG$Market_cap_growth_peer

mean(data_clean_MCG$observed_difference_TQ)

data_clean_MCG$shifted_group1_TQ <- data_clean_MCG$observed_difference_TQ - mean(data_clean_MCG$observed_difference_TQ)

mean(data_clean_MCG$shifted_group1_TQ)

# Perform the bootstrap analysis
set.seed(123)
B <- 100000
boot_results_shifted_group1 <- boot(data_clean_MCG$shifted_group1_TQ, bootstrap_mean, R = B)

# Extract the bootstrapped mean differences from the 't' column of the boot_results_shifted_group1 object
bootstrapped_means <- boot_results_shifted_group1$t

# Create a dataframe for ggplot
bootstrapped_means_df <- data.frame(means = bootstrapped_means)

# Create the histogram
ggplot(bootstrapped_means_df, aes(x = means)) +
  geom_histogram(binwidth = 0.01, fill = "steelblue", color = "black") +
  labs(title = "Histogram of Bootstrapped Mean Differences",
       x = "Mean Difference",
       y = "Frequency") +
  theme_minimal()

# Calculate the observed mean difference
observed_mean_difference_TQ <- mean(data_clean_MCG$Market_cap_growth) - mean(data_clean_MCG$Market_cap_growth_peer)

# Step 3: Calculate the p-value
p_value_perm_TQ <- mean(bootstrapped_means >= observed_mean_difference_TQ)
print(p_value_perm_TQ)

######### Hypothesis 12 - Not due to luck 

#### Individual 

## Define a function that computes the alpha for a resampled dataset using the pre-calculated alphas

data_clean <- data_clean %>%
  mutate(Q1 = quantile(Alpha, 0.25, na.rm = TRUE),
         Q3 = quantile(Alpha, 0.75, na.rm = TRUE),
         IQR = Q3 - Q1,
         lower_bound = Q1 - 20 * IQR,
         upper_bound = Q3 + 20 * IQR,
         outlierAlpha = Alpha < lower_bound | Alpha > upper_bound) %>%
  select(-Q1, -Q3, -IQR, -lower_bound, -upper_bound)

data_clean_alpha <- data_clean %>%
  filter(!outlierAlpha) %>%
  select(-contains("outlier"))

bootstrap_alpha <- function(alpha, indices) {
  resampled_alpha <- alpha[indices]
  return(resampled_alpha)
}

# Perform the bootstrap resampling using the boot() function:

library(boot)

alpha_vector <- data_clean_alpha$Alpha # Access the 'Alpha' column from the 'data_clean_MCG' dataframe
alpha_vector <- alpha_vector[!is.na(alpha_vector)] # # Remove NA values from the alpha vector
boot_results <- boot(alpha_vector, bootstrap_alpha, R = 10000)


### Calculate the p-value

# Initialize a vector to store the p-values
p_values <- numeric(length(alpha_vector))

# Iterate over the alpha_vector and compare each observed alpha to the resampled alphas
for (i in 1:length(alpha_vector)) {
  observed_alpha <- alpha_vector[i]
  p_values[i] <- sum(boot_results$t[,i] >= observed_alpha) / boot_results$R
}

significance_level <- 0.05
num_significant <- sum(p_values < significance_level)
proportion_significant <- num_significant / length(p_values)

### 5% of investments have an alpha that is high enough that I can be reasonably sure that it is due to skill and not luck that the return is outsized

library(ggplot2)

ggplot(data.frame(p_values), aes(x = p_values)) +
  geom_histogram(breaks = seq(0, 1, by = 0.05), fill = "steelblue", color = "black") +
  labs(x = "p-value", y = "Frequency") +
  theme_minimal()

num_bins <- ceiling(1 + 3.322 * log10(length(p_values)))
observed_counts <- hist(p_values, breaks = seq(0, 1, by = 1/num_bins), plot = FALSE)$counts
expected_probabilities <- rep(1 / num_bins, num_bins)
chisq_test <- chisq.test(observed_counts, p = expected_probabilities)
print(chisq_test)

## probability not significantly different from a uniform distribution

#### Collective 

### Collective but studentized 

#Null hypothesis is that alpha is not different from 0 

#Define the test statistic
studentized_mean_alpha_TQ <- function(alpha, indices) {
  resampled_alpha <- alpha[indices]
  resampled_mean_alpha <- mean(resampled_alpha)
  resampled_se_alpha <- sd(resampled_alpha) / sqrt(length(resampled_alpha))
  studentized_stat <- (resampled_mean_alpha - mean(alpha)) / resampled_se_alpha
  return(c(studentized_stat, resampled_se_alpha))
}

library(boot)

## Shift  the data to 0 to test for extremity of the result I got 

mean(data_clean_alpha$Alpha)

data_clean_alpha$Alpha_shifted = data_clean_alpha$Alpha - mean(data_clean_alpha$Alpha)

mean(data_clean_alpha$Alpha_shifted)

boot_results_mean_TQ1 <- boot(data_clean_alpha$Alpha_shifted, studentized_mean_alpha_TQ, R = 100000)

# Calculate the studentized bootstrap confidence interval
boot_ci <- boot.ci(boot_results_mean_TQ, conf = 0.90, type = "stud")
print(boot_ci)

## CI includes mean of alpha, therefore it is likely luck

observed_mean_alpha_TQ1 <- mean(data_clean_alpha$Alpha)

observed_se_alpha_TQ1 <- sd(data_clean_alpha$Alpha) / sqrt(length(data_clean_alpha$Alpha))

observed_studentized_alpha_TQ1 <- (observed_mean_alpha_TQ1 - mean(data_clean_alpha$Alpha_shifted)) / observed_se_alpha_TQ1

p_value_coll_TQ1 <- sum(boot_results_mean_TQ1$t >= observed_mean_alpha_TQ1) / boot_results_mean_TQ1$R

### low p-value indicates the same thing

# Mean
mean(data_clean_alpha$Alpha)

# Median
median(data_clean_alpha$Alpha)

# Standard deviation
sd(data_clean_alpha$Alpha)

# Interquartile range (IQR)
IQR(data_clean_alpha$Alpha)

print(p_value & mean_alpha & median_alpha & sd_alpha & iqr_alpha)

# Extract the bootstrapped mean alphas from the 't' column of the boot_results_mean object
bootstrapped_means_TQ_collective2 <- boot_results_mean_TQ1$t

# Create a dataframe for ggplot
bootstrapped_means_df_TQ2 <- data.frame(means = bootstrapped_means_TQ_collective2)

# Create the histogram
ggplot(bootstrapped_means_df_TQ2, aes(x = V1)) +
  geom_histogram(binwidth = 0.05, fill = "steelblue", color = "black") +
  labs(title = "Histogram of Bootstrapped Mean Alphas",
       x = "Mean Alpha",
       y = "Frequency") +
  theme_minimal()
